from django.urls import path
from django.views.generic import RedirectView 
from .views import UploadManifestView, ReviewDashboardView, RowValidationAPIView

app_name = 'assetreview'

urlpatterns = [

    path('', RedirectView.as_view(pattern_name='assetreview:upload', permanent=False)),
    
    path('upload/', UploadManifestView.as_view(), name='upload'),
    path('review/', ReviewDashboardView.as_view(), name='review'),
    path('api/validate/', RowValidationAPIView.as_view(), name='validate_row'),
]