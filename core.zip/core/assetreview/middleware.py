from django.http import HttpResponseBadRequest
from django.conf import settings

class MaxUploadSizeMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response
        # Default to 2MB if not specified in settings
        self.max_size = getattr(settings, 'MAX_UPLOAD_SIZE', 2 * 1024 * 1024)

    def __call__(self, request):
        if request.method == 'POST' and request.path.endswith('/upload/'):
            content_length = request.META.get('CONTENT_LENGTH')
            if content_length:
                try:
                    if int(content_length) > self.max_size:
                        return HttpResponseBadRequest("File size exceeds the allowed limit.")
                except (ValueError, TypeError):
                    return HttpResponseBadRequest("Invalid Content-Length header.")
        return self.get_response(request)