// Function responsible for changing the location context seamlessly matching filter updates
function applyFilterView(selectedFilter) {
    // Set cookie immediately so that it persists during subsequent page refreshes
    document.cookie = "asset_filter=" + selectedFilter + "; path=/; max-age=" + (3600 * 24 * 7);
    
    // Perform parameter injection to reload context from the host view
    const url = new URL(window.location.href);
    url.searchParams.set('filter', selectedFilter);
    window.location.href = url.toString();
}

// Handler dealing with AJAX updates via application/json formatting specs
function processRow(rowId, actionType) {
    fetch(validateUrl, {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            "X-CSRFToken": csrfToken
        },
        body: JSON.stringify({
            row_id: rowId,
            action: actionType
        })
    })
    .then(response => {
        if (!response.ok) {
            throw new Error("Network request validation exception occurred.");
        }
        return response.json();
    })
    .then(data => {
        if (data.success) {
            const targetRow = document.getElementById("row-" + rowId);
            if (targetRow) {
                // Wipe clean baseline status representations
                targetRow.className = "";
                targetRow.classList.add("status-" + data.new_status);
            }
        } else {
            alert("Error managing asset data workflow updates: " + data.error);
        }
    })
    .catch(error => {
        console.error("AJAX validation exception:", error);
        alert("An error occurred during AJAX transaction lifecycle execution pipeline.");
    });
}