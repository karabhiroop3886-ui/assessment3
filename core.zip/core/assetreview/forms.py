import csv
import io
from django import forms
from django.core.exceptions import ValidationError

REQUIRED_HEADERS = ['asset_code', 'day_no', 'asset_type', 'filename']

class CSVUploadForm(forms.Form):
    manifest_file = forms.FileField(label="Select Manifest CSV")

    def clean_manifest_file(self):
        uploaded_file = self.cleaned_data['manifest_file']
        
        if not uploaded_file.name.endswith('.csv'):
            raise ValidationError("The uploaded file must be a CSV.")
            
        if uploaded_file.size == 0:
            raise ValidationError("The uploaded file is empty.")

        # Read sample bytes to safely parse and validate headers
        try:
            # Read first few lines or entire file into memory string safely
            content = uploaded_file.read().decode('utf-8')
            uploaded_file.seek(0) # Reset pointer for future file persistence
            
            stream = io.StringIO(content)
            reader = csv.reader(stream)
            headers = next(reader, None)
        except Exception:
            raise ValidationError("Unable to parse or read CSV format.")

        if not headers:
            raise ValidationError("CSV file contains no readable content.")

        # Strip spaces and validate match
        cleaned_headers = [h.strip() for h in headers if h.strip()]
        for required in REQUIRED_HEADERS:
            if required not in cleaned_headers:
                raise ValidationError(f"Missing mandatory header column: '{required}'.")

        return uploaded_file