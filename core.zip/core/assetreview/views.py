import os
import csv
import io
import json
from django.shortcuts import render, redirect
from django.urls import reverse
from django.views import View
from django.views.generic import TemplateView
from django.http import JsonResponse, HttpResponseBadRequest
from django.conf import settings
from django.core.files.storage import FileSystemStorage
from .forms import CSVUploadForm

class UploadManifestView(View):
    def get(self, request):
        form = CSVUploadForm()
        return render(request, 'assetreview/upload.html', {'form': form})

    def post(self, request):
        form = CSVUploadForm(request.POST, request.FILES)
        if form.is_valid():
            manifest = request.FILES['manifest_file']
            
            # 1. Save original file to media storage
            fs = FileSystemStorage(location=os.path.join(settings.MEDIA_ROOT, 'asset_manifests'))
            filename = fs.save(manifest.name, manifest)
            
            # 2. Parse out contents and categorize into memory structures safely
            manifest.seek(0)
            content = manifest.read().decode('utf-8')
            stream = io.StringIO(content)
            reader = csv.DictReader(stream)
            
            parsed_rows = []
            for idx, row in enumerate(reader):
                # Clean keys & values to bypass trailing/leading layout quirks
                cleaned_row = {k.strip(): v.strip() if v else "" for k, v in row.items()}
                
                # Check for baseline logic validation issues here
                status = "valid"
                warnings = []
                
                if not cleaned_row.get('asset_code') or not cleaned_row.get('filename'):
                    status = "warning"
                    warnings.append("Missing required asset code or filename value.")
                
                try:
                    int(cleaned_row.get('day_no', 0))
                except ValueError:
                    status = "warning"
                    warnings.append("Day field is not a number.")

                parsed_rows.append({
                    "id": idx,
                    "data": cleaned_row,
                    "status": status,
                    "warnings": warnings
                })

            # 3. Store processed output into JSON artifact context file
            json_filename = f"{os.path.splitext(filename)[0]}.json"
            json_path = os.path.join(settings.MEDIA_ROOT, 'asset_manifests', json_filename)
            
            with open(json_path, 'w', encoding='utf-8') as f:
                json.dump(parsed_rows, f, indent=4)
                
            # 4. Save dynamic reference pointer using persistent pathing inside execution context
            request.session['current_manifest_json'] = json_path
            
            # Redirect smoothly to validation screen
            return redirect(reverse('assetreview:review'))
            
        return render(request, 'assetreview/upload.html', {'form': form})


class ReviewDashboardView(TemplateView):
    template_name = 'assetreview/review.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        # Fetch the path from session state or explicit variable tracking
        json_path = self.request.session.get('current_manifest_json')
        
        # Check active filter cookie or fall back to default
        active_filter = self.request.COOKIES.get('asset_filter', 'all')
        context['active_filter'] = active_filter
        
        if not json_path or not os.path.exists(json_path):
            context['rows'] = []
            context['error'] = "No valid preview manifest file open or loaded."
            return context

        with open(json_path, 'r', encoding='utf-8') as f:
            all_rows = json.load(f)

        # Filter items according to cookie visibility context cleanly inside view logic
        if active_filter == 'all':
            filtered_rows = all_rows
        else:
            filtered_rows = [r for r in all_rows if r['status'] == active_filter]

        context['rows'] = filtered_rows
        return context

    def render_to_response(self, context, **response_kwargs):
        response = super().render_to_response(context, **response_kwargs)
        # Re-verify and maintain cookie context lifecycle rules
        active_filter = self.request.GET.get('filter') or self.request.COOKIES.get('asset_filter', 'all')
        response.set_cookie('asset_filter', active_filter, max_age=3600*24*7)
        return response


class RowValidationAPIView(View):
    """
    Protected dynamic AJAX validation endpoint handling validation mutation states
    without updating native SQL backends.
    """
    def post(self, request, *args, **kwargs):
        try:
            data = json.loads(request.body)
            row_id = int(data.get('row_id'))
            action = data.get('action') # 'approve' or 'reject'
        except (ValueError, TypeError, json.JSONDecodeError):
            return JsonResponse({'success': False, 'error': 'Invalid request parameters.'}, status=400)

        json_path = request.session.get('current_manifest_json')
        if not json_path or not os.path.exists(json_path):
            return JsonResponse({'success': False, 'error': 'Manifest lifecycle context lost.'}, status=400)

        # Mutate temporary structured data tracking states safely
        with open(json_path, 'r+', encoding='utf-8') as f:
            rows = json.load(f)
            
            target_row = next((r for r in rows if r['id'] == row_id), None)
            if not target_row:
                return JsonResponse({'success': False, 'error': 'Target row identity not found.'}, status=404)

            # Mutate state context matching requirements
            target_row['status'] = 'valid' if action == 'approve' else 'rejected'
            
            f.seek(0)
            json.dump(rows, f, indent=4)
            f.truncate()

        return JsonResponse({'success': True, 'new_status': target_row['status']})